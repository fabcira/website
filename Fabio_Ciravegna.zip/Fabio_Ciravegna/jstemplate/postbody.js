

document.write("    <!--copyright footer-->")
document.write("    <script type='text/javascript' src='./jstemplate/footer.js'> </script>")

document.write("<!-- JS and analytics only. -->")
document.write("<!-- Bootstrap core JavaScript")
document.write("================================================== -->")
document.write("<!-- Placed at the end of the document so the pages load faster -->")
document.write("<script src='./js/jquery.js'></script>")
document.write("<script src='./js/bootstrap.js'></script>")

document.write("<script src='http://platform.twitter.com/widgets.js'></script>")
document.write("<script src='./js/holder.js'></script>")

document.write("<script src='./js/application.js'></script>")
 

document.write("<!-- Analytics")
document.write("================================================== -->")
document.write("<script>")
document.write("    var _gauges = _gauges || [];")
document.write("    (function() {")
document.write("        var t = document.createElement('script');")
document.write("        t.async = true;")
document.write("        t.id = 'gauges-tracker';")
document.write("        t.setAttribute('data-site-id', '4f0dc9fef5a1f55508000013');")
document.write("        t.src = '//secure.gaug.es/track.js';")
document.write("        var s = document.getElementsByTagName('script')[0];")
document.write("        s.parentNode.insertBefore(t, s);")
document.write("    })();")
document.write("</script>")

document.write("</div>")
document.write("</div>")