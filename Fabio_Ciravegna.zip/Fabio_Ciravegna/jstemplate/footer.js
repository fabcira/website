document.write("<div class='panel-footer' style='text-align: center; font-size:8pt'> &copy; Fabio Ciravegna, University of Sheffield</div>")
document.write("<script type='text/javascript'>")

document.write("  var _gaq = _gaq || [];")
document.write("  _gaq.push(['_setAccount', 'UA-27734045-1']);")
document.write("  _gaq.push(['_trackPageview']);")

document.write("  (function() {")
document.write("    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;")
document.write("    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';")
document.write("    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);")
document.write("  })();")

document.write("</script>")